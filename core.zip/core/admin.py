from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(User)
admin.site.register(Student)
admin.site.register(GroupSession)
admin.site.register(StudentAttend)
admin.site.register(MemorizedPages)
admin.site.register(Hadith)
admin.site.register(Page)